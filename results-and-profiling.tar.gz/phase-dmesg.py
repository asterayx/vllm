"""Supplementary phase-end kernel evidence; failures are warnings only."""
import json
import pathlib
import subprocess
import sys
import time

out = pathlib.Path.home() / 'vllm-v034-c1' / sys.argv[1]
phase = sys.argv[2]
since = json.loads((out / 'oom-before.json').read_text())['kernel_since']
row = {'phase': phase, 'time_ns': time.time_ns()}
try:
    result = subprocess.run(['timeout', '--kill-after=2', '15', 'sudo', '-n', 'dmesg', '--time-format', 'iso', '--since', since], capture_output=True, text=True, timeout=18)
    row.update(returncode=result.returncode, stdout=result.stdout, stderr=result.stderr)
except Exception as exc:
    row['warning'] = repr(exc)
(out / ('kernel-phase-' + phase + '.json')).write_text(json.dumps(row, indent=2))
print('phase-end dmesg', phase, row.get('returncode', row.get('warning')))
