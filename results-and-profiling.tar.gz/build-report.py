import json,pathlib,re
r=pathlib.Path(__file__).resolve().parent
parts=[]
def add(s=''):parts.append(s)
def load(p):return json.loads(p.read_text())
def tab(head,rows):
 lines=['| '+' | '.join(head)+' |','| '+' | '.join(['---']*len(head))+' |']
 for row in rows:lines.append('| '+' | '.join(map(str,row))+' |')
 add('\n'.join(lines))
def fact(p,n):return load(p/(n+'.json'))['data']['rows']
add('# vLLM v0.34.0 合并版：C1 性能与 profiling')
if (r/'verification.json').exists():
 add('两种配置各完成240个正式响应（4×50单轮＋40多轮），全部成功；另各有32个预热请求。无草稿四个单轮测点约156–157 tok/s，较历史基线约快7%；MTP约273–277 tok/s，中位数较历史基线快3.9%–7.3%，但按原有p10–p90区间标准均记为“无可测差异”。每种配置均保留64步Nsight trace及30秒Python栈采样。')
add('测试源码：`asterayx/vllm` 分支 `integration/rtxpro5000-v0.34.0`，提交 `d77cff6e2823637d2eab077caa53d78cb6dfce7c`。本地源码在 `/workspace/vllm-integration-v0.34.0`；GPU 测试在 xzss 的 0/1/4/5 四张 RTX PRO 5000 72GB 上执行。2/3/6/7 上既有服务保留。')
add('独立运行环境：Python 3.12.15、Torch 2.14.0+cu130、FlashInfer 0.7.3、NCCL 2.30.7+cuda13.3，编译工具链 CUDA 13.5。包版本字符串仍含 editable 安装时的 `g644379a54`，本次实际源码以以上 Git 提交为准。官方 v0.34.0 预编译扩展与该源码使用同一套 C/CUDA 实现。')
add('V2 表示草稿关闭，V1 表示 MTP 2-token；这两个测试标签不是 Model Runner 版本。新分支使用 MRV2。TP4、FP8 KV、CPU pinned FP8 PLE、NCCL SYS、ardelva-lltune v5、PCIe IPC、小批量 Triton GEMM/MoE 开关沿用原方法。新版自动 attention block 为 1600 tokens；旧版无草稿为 1568。')
add('模型为`/home/roccen/models/nvidia/Qwen3.8-Flash-Next-NVFP4`；最大上下文262144、max_num_seqs=64、gpu_memory_utilization=.95。C1指并发请求数为1。服务只绑定测试端口18775，完整启动参数及环境覆盖见各配置`command.json`。')
add('**测量方法**：未修改的 `ardelva_bench.py` 与原 benchmark 客户端环境，`--conc 1 --min-requests 50 --req-per-conc 10 --warmup 8 --seed 1`。顺序固定为 3K→1000、10K→1000、32K→1000、10K→4000、多轮 60K/+5K/5 轮。模型默认采样 temperature=1/top_p=.95/top_k=20，单轮 ignore_eos=true。前四组每组 50 个测量请求；多轮 8 会话×5轮，每轮500 token。')
add('每用户 tok/s = 1000 / TPOT p50；MTP 平均接受长度含 bonus，使用 `1 + Δspec_decode_num_accepted_tokens_total / Δspec_decode_num_drafts_total`；估算每步 = TPOT p50 × 接受长度。它不是直接测量的 GPU 单步耗时。')
for label,title in [('V2','无草稿'),('V1','MTP 2-token')]:
 p=r/label
 add('**'+title+'：C1**')
 if not (p/'benchmark-summary.json').exists():add('尚未完成。');continue
 rows=[]
 for x in load(p/'benchmark-summary.json'):
  c=x['native_csv'];rows.append([x['load'],x['n'],f"{x['user_tps']:.2f}",c['out_tps'],c['tpot_p50']+'/'+c['tpot_p99'],c['ttft_p50']+'/'+c['ttft_p99'],f"{x['accept_length_including_bonus']:.4f}" if x['accept_length_including_bonus'] is not None else 'N/A',f"{x['step_ms']:.4f}" if x['step_ms'] is not None else 'N/A',x['candidate_counts'].get('measurement',0)])
 tab(['负载','请求数','每用户 tok/s','aggregate out tok/s','TPOT p50/p99 ms','TTFT p50/p99 ms','接受长度','估算每步 ms','重复/乱码候选'],rows)
add('筛查规则沿用旧轮次：替换字符、混合字母表和连续重复块。这里只计异常候选，不能替代正确性或质量评估。固定 ignore_eos 的长输出可能包含回答完成后的延续。原始文本、逐请求耗时、计数器窗口保留在各配置的 `bench` 目录。')
add('本轮未重跑模型正确性套件；请求成功仅代表服务和输出采集成功。')
if (r/'performance-comparison.json').exists():
 add('**与旧轮次的对照**')
 add('基线为 issue #55 round5，旧源码 `6b2fea9068`、Torch 2.13.0+cu132、FlashInfer 0.7.0.post1。不是同一时刻交错运行的纯源码 A/B；版本、依赖和默认运行器均有变化，其他四卡服务的负载未控制。区间标准沿用之前方法：TPOT p10–p90 重叠记为“无可测差异”。')
 rows=[]
 for x in load(r/'performance-comparison.json'):
  a,b=x['baseline'],x['integration'];rows.append([x['label'],x['load'],f"{a['tpot_p50_ms']:.4f}",f"{b['tpot_p50_ms']:.4f}",f"{a['tpot_p10_ms']:.4f}–{a['tpot_p90_ms']:.4f}",f"{b['tpot_p10_ms']:.4f}–{b['tpot_p90_ms']:.4f}",f"{x['median_user_tps_change_pct']:+.2f}%",x['interval_conclusion']])
 tab(['配置','负载','旧 TPOT p50','新 TPOT p50','旧 p10–p90','新 p10–p90','每用户速度变化','区间结论'],rows)
profiles={}
for label in ['V2','V1']:
 p=r/label/'analysis'
 if not (p/'window-summary.json').exists():continue
 s=fact(p,'window-summary')[0];ks=fact(p,'window-kernels');ranges=fact(p,'projected-ranges');n=len(ranges)
 assert n==64 and sum(x['n'] for x in ks)==s['launches'] and sum(x['ns'] for x in ks)==s['kernel_ns']
 comm=[x for x in ks if 'pcie_ipc' in x['name'].lower() or 'nccldevkernel' in x['name'].lower()]
 profiles[label]={'steps':n,'kernel_executions_per_step':s['launches']/n,'kernel_ms_per_step':s['kernel_ns']/n/1e6,'gpu_window_ms_per_step':(s['last_end']-s['first_start'])/n/1e6,'communication_ms_per_step':sum(x['ns'] for x in comm)/n/1e6,'communication_pct_of_summed_kernel_time':100*sum(x['ns'] for x in comm)/s['kernel_ns']}
add('**Nsight Systems**')
add('每种配置只采 TP0，首个文本输出后请求采集，延后50步、最多64步；CUDA/NVTX/OSRT，禁用CPU sampling和context-switch，CUDA graph按node展开。正式性能阶段已预加载注入器但未开启采集，与此前 profiling 方法一致；注入器的潜在基线开销没有另行标定。使用官方 `nvtx_gpu_proj_trace` 投影确定稳定解码起点，随后核对 graph replay 次数和最后一步。原始报告中起点前的预填充/额外数据不计入每步统计。')
tab(['配置','有效步数','kernel 次/步','累计 kernel ms/步','GPU窗口 ms/步','通信 kernel ms/步','通信占累计时间'],[[l,x['steps'],f"{x['kernel_executions_per_step']:.0f}",f"{x['kernel_ms_per_step']:.4f}",f"{x['gpu_window_ms_per_step']:.4f}",f"{x['communication_ms_per_step']:.4f}",f"{x['communication_pct_of_summed_kernel_time']:.2f}%"] for l,x in profiles.items()])
add('累计 kernel 时间包含并发 stream 的重叠，因此可能大于 GPU 窗口跨度；两者之差不能解释为 CPU 调度开销。GPU 窗口是首个到最后一个 kernel 的跨度，不能替代整个客户端请求吞吐。通信为名称可识别的 PCIe IPC/NCCL kernel 的累计时间，不是暴露在关键路径上的通信开销。')
add('采集仅代表一个TP worker，不是四卡累计值。Nsight将该卡标为logical GPU 0 / physical GPU ID 4；按UUID与PCI地址`0000:01:00.0`核对，它对应本机`nvidia-smi`的GPU 0。Nsight内部physical编号与nvidia-smi索引不能直接互换，映射保存于`gpu-index-map.csv`。')
if 'V1' in profiles:
 add('**MTP验证与草稿拆分**')
 rows=[]
 names={9020:'目标模型验证图（M=3）',9377:'MTP第一个草稿（draft prefill，M=3）',9440:'MTP第二个草稿（decode，M=1）',None:'图外采样、logits、通信和元数据等'}
 for g in sorted(fact(r/'V1/analysis','graphs'),key=lambda x:[9020,9377,9440,None].index(x['graphId'])):
  rows.append([str(g['graphId']),names[g['graphId']],g['calls'] if g['graphId'] is not None else 'N/A',f"{g['n']/64:g}",f"{g['ns']/64/1e6:.4f}"])
 tab(['graph ID','归属','replay次数','kernel次/步','累计kernel ms/步'],rows)
 add('三个图均为64次replay，所有kernel名称计数均为64的整数倍，末步完整。归属依据图的执行顺序、M=3/M=1 kernel符号，以及当前源码`TargetDependentARSpeculator.propose()`先运行draft prefill、再运行multi-step decode的逻辑；不是额外插入的逐层NVTX测量。两次草稿图合计1.1328 ms/步；图外0.5898 ms仍含目标logits及共享工作，不能把验证图7.0217 ms称为完整验证阶段的全部开销。')
 add('历史64步trace的V2/V1累计kernel为7.1711/8.9127 ms，GPU窗口为6.3648/8.6157 ms；本轮分别为7.4629/8.7443 ms和6.4025/8.3351 ms。无草稿正式请求约7%的速度提升未在这段GPU窗口中表现为同等下降，因此不能据此断言提升来自GPU kernel加速。短窗口上下文位置、依赖版本和profiler扰动不同，未作因果归因。')
for label,x in profiles.items():
 p=r/label/'analysis';ks=fact(p,'window-kernels');total=sum(t['ns'] for t in ks)
 requests_path=r/label/'profile/nsys-requests.json'
 if requests_path.exists():
  rr=load(requests_path)[0]
  elapsed=(rr['last_text_ns']-rr['first_text_ns'])/1e9
  add(f"{label} 含短段 Nsight 采集的整个4000-token请求：首末文本间 {elapsed:.3f} 秒，按3999个token间隔估算 {3999/elapsed:.2f} tok/s。它包含采集窗口之外的时间，单列记录，不纳入正式C1表，也不当作64步窗口的吞吐。")
 add('**'+label+'：前15个 kernel**')
 def short(name):
  if 'CuteSkinnyGemm' in name:
   m=re.search(r'align(?:8|16)o(\d)(2560|1536|10240)',name)
   return 'CuteSkinnyGemm '+(f'M={m[1]}, K={m[2]}' if m else '')+(' (shared gate/up)' if 'odiv22560' in name else '')
  if 'HcDownSiluFma' in name:return 'HcDownSiluFma '+('M=3' if 'o310240' in name else 'M=1')
  if 'ipc_rsag_push_param_kernel' in name:return 'PCIe IPC push RSAG'
  if 'gemvx' in name:
   variant=next((str(i) for i in [5,6,7] if f'(int){i}' in name),'?')
   return 'internal::gemvx::kernel variant '+variant
  if 'topkGating' in name:return 'vllm::moe::topkGating'
  if 'splitKreduce' in name:return 'cublasLt::splitKreduce_kernel'
  if 'moe_align_block_size' in name:return 'moe_align_block_size_kernel'
  if 'gdn_decode_post_conv' in name:return 'gdn_decode_post_conv_mtp_kernel<float,3,true,4>'
  return name[:125].replace('|','/')
 tab(['ID/短名','次/步','均值 µs/次','ms/步','累计时间占比'],[[f"K{i} `{short(t['name'])}`",f"{t['n']/64:g}",f"{t['ns']/t['n']/1000:.3f}",f"{t['ns']/64/1e6:.4f}",f"{100*t['ns']/total:.2f}%"] for i,t in enumerate(ks[:15],1)])
 add(f'完整符号与此排序一一对应，见 `{label}/analysis/window-kernels.json`；同名通用 GEMM 不按猜测分配给某层。')
 comm=[t for t in ks if 'pcie_ipc' in t['name'].lower() or 'nccldevkernel' in t['name'].lower()]
 add('通信 kernel 明细：')
 tab(['kernel','次/步','µs/次','ms/步'],[[short(t['name']),f"{t['n']/64:g}",f"{t['ns']/t['n']/1000:.3f}",f"{t['ns']/64/1e6:.4f}"] for t in comm])
 if (p/'window-api-clipped.json').exists():
  add('CUDA API：使用相邻首/末 NVTX 起点之间的63个完整主机迭代区间，按边界裁剪 API 时间。时间可跨线程重叠，不能与 GPU 时间相加。')
  tab(['API','调用数','窗口累计 ms','均摊 ms/步'],[[t['name'],t['n'],f"{t['ns']/1e6:.4f}",f"{t['ns']/63/1e6:.4f}"] for t in fact(p,'window-api-clipped')[:10]])
 pp=r/label/'profile'
 if (pp/'pyspy-summary.json').exists():
  main=load(pp/'pyspy-summary.json')[0];add(f"Python 栈：主线程 {main['samples']} 个样本，leaf 前五如下。这是采样栈比例，不是 CPU 利用率；跨连续长输出请求，包含请求边界。")
  tab(['leaf 栈帧','样本权重占比'],[[t['frame']['name']+' ('+pathlib.Path(t['frame'].get('file','')).name+')',f"{t['sampled_weight_percent']:.2f}%"] for t in main['top_leaf'][:5]])
add('**采集记录与限制**')
add('首次无草稿运行完成3K测点后，旧抓包解析器将采集边界截断的 `/metrics` 响应判为错误，外层调度器停止实例。已验证50条测量输出完整且逐条匹配原生JSON；修正仅针对监控GET连接的解析。该次数据单列在 `V2-attempt1`，正式表使用重新启动后连续完成的五组测试。模型和官方benchmark未修改。')
add('V2原始dmon贯穿运行，但带绝对时间的dmon是在长输出正式窗口中途补开；前三组不提供伪精确的逐测点GPU利用率区间。V1从启动即使用带时间戳dmon。')
add('启动采用独立缓存和已验证的CUDA_HOME/动态库路径设置，保留OOM计数监控和本次进程oom_score_adj=1000；沿用用户授权，不设内存余量停止线。两种配置均在测试与采集完成后请求停止，常规退出等待超时后由本次监督器强制清理（exit -9，reason=requested_stop），采集文件已完整保存；这不是测试中途失败。')
if (r/'verification.json').exists():add('最终核查：`verification.json` 保存源码/包清单、GPU进程和OOM计数的前后对照。')
else:add('最终清理与环境核查尚待本轮全部测试结束。')
add('复现脚本：`env.sh`、`run-server.py`、`run-benchmark.py`、`profile-launcher.py`、`profile-client.py`、`collect-profile.py`。完整命令和覆盖环境见每种配置的 `command.json` 与 `bench/status.json`。本地原始 `.nsys-rep` 和 `.speedscope.json` 均保留。')
add('本地数据索引：`V1/benchmark-summary.json`、`V2/benchmark-summary.json`（性能及接受率）；`performance-comparison.json`（历史区间对照）；`profile-summary.json`（64步汇总）；`V1/profile/trace.nsys-rep`、`V2/profile/trace.nsys-rep`（Nsight原始报告）；`V1/profile/worker.speedscope.json`、`V2/profile/worker.speedscope.json`（Python采样）；各配置的`analysis/`保存支持查询返回的证据。完整原始抓包保留在xzss的`/home/roccen/vllm-v034-c1`，本地同步了解析输出及原生benchmark JSON，未复制pcap。')
if (r/'verification.json').exists():
 v=load(r/'verification.json')
 add(f"最终状态：两份源码工作区干净，原服务及合并版包清单均未改变；benchmark与输入哈希通过；原有四个GPU进程PID/UUID集合不变，本次测试GPU无残留计算进程；系统OOM计数{v['oom_kill_before']}→{v['oom_kill_after']}。")
(r/'profile-summary.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2)+'\n')
(r/'REPORT.md').write_text('\n\n'.join(parts)+'\n')
print('Report written; completed profile variants:',list(profiles))
