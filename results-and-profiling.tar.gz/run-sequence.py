import json, os, pathlib, signal, subprocess, time, traceback
root=pathlib.Path.home()/'vllm-v034-c1'
py=str(pathlib.Path.home()/'vllm-integration-v0.34.0/.venv/bin/python')
client=str(pathlib.Path.home()/'vllm/.venv/bin/python')
rows=[]
def status():
 (root/'sequence-status.json').write_text(json.dumps(rows,indent=2))
def stop(label):
 f=root/label/'pid.json'
 if f.exists() and not (root/label/'exit.json').exists():
  pid=json.loads(f.read_text())['runner_pid']
  try:os.kill(pid,signal.SIGTERM)
  except ProcessLookupError:pass
  end=time.monotonic()+70
  while not (root/label/'exit.json').exists() and time.monotonic()<end:time.sleep(1)
  if not (root/label/'exit.json').exists():raise RuntimeError('supervisor failed cleanup')
def run(label,phase,cmd,timeout):
 row={'label':label,'phase':phase,'start_ns':time.time_ns(),'command':cmd};rows.append(row);status()
 with (root/label/(phase+'.log')).open('w') as f:
  result=subprocess.run(['choom','-n','1000','--','timeout','--kill-after=20',str(timeout),*cmd],stdout=f,stderr=subprocess.STDOUT)
 row.update(returncode=result.returncode,end_ns=time.time_ns());status()
 if result.returncode:raise RuntimeError(f'{label} {phase} returned {result.returncode}')
for label in ['V2','V1']:
 try:
  if label=='V1':
   assert not (root/label).exists()
   with (root/(label+'-supervisor.log')).open('w') as f:
    subprocess.Popen(['choom','-n','1000','--','timeout','--kill-after=45','21660',py,str(root/'run-server.py'),label],cwd=root,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  start=time.monotonic()
  while not (root/label/'ready.json').exists():
   if (root/label/'exit.json').exists():raise RuntimeError('server exited before ready')
   if time.monotonic()-start>5500:raise RuntimeError('startup wait timeout')
   time.sleep(2)
  run(label,'benchmark', [client,str(root/'run-benchmark.py'),label],10800)
  run(label,'analyze-benchmark',[client,str(root/'analyze-benchmark.py'),str(root/label),label],180)
  run(label,'profile-pyspy',[client,str(root/'profile-client.py'),label,'pyspy'],600)
  run(label,'profile-nsys',[client,str(root/'profile-client.py'),label,'nsys'],600)
  stop(label)
  # Nsight finalizes when the profiled worker exits.
  limit=time.monotonic()+60
  while not (root/label/'profile/trace.nsys-rep').exists() and time.monotonic()<limit:time.sleep(1)
  if not (root/label/'profile/trace.nsys-rep').exists():raise RuntimeError('Nsight report missing')
 except Exception:
  (root/'sequence-error.txt').write_text(traceback.format_exc())
  stop(label)
  raise
(root/'sequence-complete.json').write_text(json.dumps({'time_ns':time.time_ns()}))
