O="$HOME/vllm-v034-c1"
L="$HOME/vllm-integration-v0.34.0/.venv/lib/python3.12/site-packages/nvidia/cu13/lib"
export PATH="$HOME/vllm-integration-v0.34.0/.venv/bin:$PATH"
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0,1,4,5
export LD_LIBRARY_PATH="$O/lib:$L"
export LIBRARY_PATH="$O/lib:$L"
export FLASHINFER_WORKSPACE_BASE="$O/cache/flashinfer"
export FLASHINFER_AUTOTUNE_CACHE_DIR="$O/cache/flashinfer-managed"
export VLLM_FLASHINFER_AUTOTUNE_CACHE_DIR="$O/cache/vllm-autotune"
export VLLM_CACHE_ROOT="$O/cache/vllm"
export XDG_CACHE_HOME="$O/cache/xdg"
export CUDA_CACHE_PATH="$O/cache/cuda"
export TRITON_CACHE_DIR="$O/cache/triton"
export TORCHINDUCTOR_CACHE_DIR="$O/cache/torchinductor"
export TORCH_EXTENSIONS_DIR="$O/cache/torch-extensions"
export MAX_JOBS=1 FLASHINFER_NVCC_THREADS=1
export FLASHINFER_LOGGING_LEVEL=debug
export CUDA_HOME=/usr/local/cuda-13.5
export FLASHINFER_NVCC="$CUDA_HOME/bin/nvcc"
export CUTE_DSL_CACHE_DIR="$O/cache/cute-dsl"
export CUTE_DSL_DUMP_DIR="$O/cache/cute-dump"
export TMPDIR="$O/tmp"
