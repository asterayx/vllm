"""Compare complete saved requests, without changing benchmark timing."""
import json, pathlib, statistics
root=pathlib.Path(__file__).resolve().parent
old=pathlib.Path('/workspace/issue55/round5')
def quantile(xs,q):
 xs=sorted(xs);n=(len(xs)-1)*q;i=int(n)
 return xs[i]+(xs[min(i+1,len(xs)-1)]-xs[i])*(n-i)
def interval(path):
 d=json.loads(path.read_text())
 vals=[1000*(lat-ttft)/(n-1) for lat,ttft,n in zip(d['latencies'],d['ttfts'],d['output_lens']) if n>1]
 assert len(vals)==50 and d['completed']==50 and d['failed']==0
 return {'tpot_p10_ms':quantile(vals,.1),'tpot_p50_ms':statistics.median(vals),'tpot_p90_ms':quantile(vals,.9),'user_tps_p10':1000/quantile(vals,.9),'user_tps_p50':1000/statistics.median(vals),'user_tps_p90':1000/quantile(vals,.1)}
rows=[]
for label in ['V2','V1']:
 for load in ['realtext3k-1000','realtext10k-1000','realtext32k-1000','realtext10k-4000']:
  new=root/label/'bench'/load/'custom_c1.json';base=old/label/'bench'/load/'custom_c1.json'
  if not new.exists():continue
  a=interval(base);b=interval(new)
  overlap=max(a['tpot_p10_ms'],b['tpot_p10_ms'])<=min(a['tpot_p90_ms'],b['tpot_p90_ms'])
  rows.append({'label':label,'load':load,'baseline':a,'integration':b,'p10_p90_overlap':overlap,'interval_conclusion':'无可测差异' if overlap else ('本轮区间更低' if b['tpot_p90_ms']<a['tpot_p10_ms'] else '本轮区间更高'),'median_user_tps_change_pct':(b['user_tps_p50']/a['user_tps_p50']-1)*100})
(root/'performance-comparison.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(rows,ensure_ascii=False,indent=2))
