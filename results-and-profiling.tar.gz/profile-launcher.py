"""External launcher: arm Nsight on TP rank 0 only, with collection deferred.

No model/benchmark files are edited. The original NUMA executable and arguments
are preserved. Import-time setup is required for multiprocessing spawn children.
"""
import contextlib
import json
import multiprocessing.spawn
import os
from pathlib import Path
import shlex

from vllm.utils import numa_utils

original = numa_utils.configure_subprocess


@contextlib.contextmanager
def configure_profiled_rank(vllm_config, local_rank, dp_local_rank=None, process_kind='worker'):
    with original(vllm_config, local_rank, dp_local_rank, process_kind):
        if process_kind != 'worker' or local_rank != 0:
            yield
            return
        output = Path(os.environ['ISSUE55_PROFILE_OUTPUT'])
        old = os.fsdecode(multiprocessing.spawn.get_executable())
        nsys = '/opt/nvidia/nsight-systems/2026.5.2/target-linux-x64/nsys'
        command = ['choom', '-n', '1000', '--', nsys, 'profile',
                   '--trace=cuda,nvtx,osrt', '--sample=none', '--cpuctxsw=none',
                   '--trace-fork-before-exec=true', '--cuda-graph-trace=node',
                   '--start-later=true', '--capture-range=cudaProfilerApi',
                   '--capture-range-end=stop', '--wait=primary',
                   '--session-new=' + os.environ['ISSUE55_NSYS_SESSION'],
                   '--output=' + str(output / 'trace'), old]
        wrapper = output / 'rank0-executable.sh'
        assert not wrapper.exists(), 'Refuse a second TP0 launch'
        wrapper.write_text('#!/bin/sh\n'
                           + 'case "$*" in *--multiprocessing-fork*) ;; *) exec ' + shlex.quote(old) + ' "$@" ;; esac\n'
                           + "printf '%s\\n' \"$$\" > " + shlex.quote(str(output / 'nsys-wrapper.pid')) + '\n'
                           + 'exec ' + shlex.join(command) + ' "$@"\n')
        wrapper.chmod(0o700)
        (output / 'rank0-launch.json').write_text(json.dumps({
            'logical_rank': local_rank, 'original_executable': old,
            'prefix': command, 'collection_deferred_until_nsys_start': True,
        }, indent=2))
        multiprocessing.spawn.set_executable(str(wrapper))
        try:
            yield
        finally:
            multiprocessing.spawn.set_executable(old)


numa_utils.configure_subprocess = configure_profiled_rank

if __name__ == '__main__':
    from vllm.entrypoints.cli.main import main
    main()
