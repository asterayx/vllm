set -eu
cd "$HOME/vllm-v034-c1"
mkdir -p lib tmp cache
for n in cublas cublasLt cudart; do
  ln -s "$HOME/vllm-integration-v0.34.0/.venv/lib/python3.12/site-packages/nvidia/cu13/lib/lib${n}.so.13" "lib/lib${n}.so"
done
. ./env.sh
mkdir -p "$FLASHINFER_WORKSPACE_BASE" "$FLASHINFER_AUTOTUNE_CACHE_DIR" "$VLLM_FLASHINFER_AUTOTUNE_CACHE_DIR" "$VLLM_CACHE_ROOT" "$XDG_CACHE_HOME" "$CUDA_CACHE_PATH" "$TRITON_CACHE_DIR" "$TORCHINDUCTOR_CACHE_DIR" "$TORCH_EXTENSIONS_DIR" "$CUTE_DSL_CACHE_DIR" "$CUTE_DSL_DUMP_DIR"
"$HOME/.local/bin/uv" pip freeze --python "$HOME/vllm-integration-v0.34.0/.venv/bin/python" > packages-integration-before.txt
"$HOME/.local/bin/uv" pip freeze --python "$HOME/vllm/.venv/bin/python" > packages-serving-before.txt
git -C "$HOME/vllm-integration-v0.34.0" rev-parse HEAD > source-before.txt
sha256sum "$HOME/strata-issue54/ardelva-lib/scripts/bench/ardelva_bench.py" "$HOME/ardelva/realtext_v13_qwen_20261105/"*.jsonl > inputs-before.sha256
"$HOME/vllm-integration-v0.34.0/.venv/bin/python" - <<'PY'
import ast,pathlib
for p in pathlib.Path('.').glob('*.py'):ast.parse(p.read_text())
import torch, vllm, flashinfer
print('torch',torch.__version__,'vllm',vllm.__version__,'flashinfer',flashinfer.__version__)
print('source',vllm.__file__)
PY
ss -ltn | grep ':18775 ' && exit 1 || true
nohup choom -n 1000 -- timeout --signal=TERM --kill-after=45 21660 \
 "$HOME/vllm-integration-v0.34.0/.venv/bin/python" run-server.py V2 \
 >V2-supervisor.log 2>&1 </dev/null &
echo "supervisor_wrapper=$!"
