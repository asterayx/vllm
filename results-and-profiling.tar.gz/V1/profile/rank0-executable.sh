#!/bin/sh
case "$*" in *--multiprocessing-fork*) ;; *) exec /home/roccen/vllm-integration-v0.34.0/vllm/utils/numa_wrapper.sh "$@" ;; esac
printf '%s\n' "$$" > /home/roccen/vllm-v034-c1/V1/profile/nsys-wrapper.pid
exec choom -n 1000 -- /opt/nvidia/nsight-systems/2026.5.2/target-linux-x64/nsys profile --trace=cuda,nvtx,osrt --sample=none --cpuctxsw=none --trace-fork-before-exec=true --cuda-graph-trace=node --start-later=true --capture-range=cudaProfilerApi --capture-range-end=stop --wait=primary --session-new=vllm-v034-c1-r2-v1 --output=/home/roccen/vllm-v034-c1/V1/profile/trace /home/roccen/vllm-integration-v0.34.0/vllm/utils/numa_wrapper.sh "$@"
