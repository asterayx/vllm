"""Run the unchanged official benchmark, in the issue's specified order."""
import json, os, pathlib, subprocess, sys, time, urllib.request
from owned import register
home = pathlib.Path.home()
root = home / 'vllm-v034-c1'
label = sys.argv[1]
out = root / label / 'bench'
out.mkdir(exist_ok=False)
assert (root / label / 'ready.json').exists()
env = os.environ.copy()
env.update(CUDA_VISIBLE_DEVICES='', PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1')
common = [str(home / 'vllm/.venv/bin/python'), str(home / 'strata-issue54/ardelva-lib/scripts/bench/ardelva_bench.py'),
          '--base-url', 'http://127.0.0.1:18775', '--model', 'qwen3.8-flash-next',
          '--tokenizer', str(home / 'models/nvidia/Qwen3.8-Flash-Next-NVFP4'),
          '--conc', '1', '--min-requests', '50', '--req-per-conc', '10', '--warmup', '8', '--seed', '1',
          '--vllm', str(root / 'bench-with-metrics.py')]
loads = [('realtext3k-1000','3k',1000), ('realtext10k-1000','10k',1000), ('realtext32k-1000','32k',1000), ('realtext10k-4000','10k',4000), ('multiturn',None,500)]
rows = []
def scrape(path):
    with urllib.request.urlopen('http://127.0.0.1:18775/metrics', timeout=10) as response:
        path.write_bytes(response.read())
for name, size, output_length in loads:
    assert not (root / label / 'exit.json').exists(), 'Server exited'
    point = out / name
    point.mkdir()
    args = ['--dataset', 'custom:' + str(home / f'ardelva/realtext_v13_qwen_20261105/realtext_{size}.jsonl'), '--output-len', str(output_length)] if size else ['--dataset', 'multiturn:60000:5000:5']
    (root / label / 'phase.txt').write_text('benchmark_' + name)
    command = ['timeout', '--kill-after=20', '5400', *common, *args, '--out', str(point)]
    scrape(point / 'whole-before.metrics')
    start = time.time_ns()
    (out / 'active.json').write_text(json.dumps({'load': name, 'start_ns': start, 'command': command}, indent=2))
    capture_log = (point / 'capture.log').open('w')
    capture = subprocess.Popen(['choom', '-n', '1000', '--', 'timeout', '--kill-after=10', '5500', 'sudo', '-n', 'tcpdump', '-Z', 'roccen', '-i', 'lo', '-n', '-s', '0', '-B', '4096', '-w', str(point / 'requests.pcap'), 'tcp port 18775 and host 127.0.0.1'], stdout=capture_log, stderr=subprocess.STDOUT, start_new_session=True)
    register(root / label, capture)
    time.sleep(0.5)
    if capture.poll() is not None:raise RuntimeError('Test-response capture did not start')
    with (point / 'bench.log').open('w') as f:
        result = subprocess.Popen(['choom', '-n', '1000', '--', *command], env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
        register(root / label, result)
        while result.poll() is None:
            if (root / label / 'exit.json').exists() or (root / label / 'oom-stop.json').exists() or (root / label / 'memory-guard.json').exists():
                import signal
                os.killpg(result.pid, signal.SIGTERM)
                try:result.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(result.pid, signal.SIGKILL); result.wait(timeout=5)
                os.killpg(capture.pid, signal.SIGINT)
                capture.wait(timeout=10); capture_log.close()
                raise RuntimeError('Server or guard stopped; stopped benchmark process group')
            time.sleep(0.5)
    import signal
    os.killpg(capture.pid, signal.SIGINT)
    try:capture.wait(timeout=10)
    except subprocess.TimeoutExpired:
        os.killpg(capture.pid, signal.SIGKILL); capture.wait(timeout=5)
    capture_log.close()
    scrape(point / 'whole-after.metrics')
    row = {'load': name, 'command': command, 'returncode': result.returncode, 'start_ns': start, 'end_ns': time.time_ns()}
    rows.append(row)
    (out / 'status.json').write_text(json.dumps(rows, indent=2))
    print(name, result.returncode, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    # The official script can return zero even when a measurement failed.
    csvs = list(point.glob('*.csv'))
    if not csvs or not any(len(p.read_text().splitlines()) > 1 for p in csvs):
        raise RuntimeError('No successful measurement CSV: ' + name)

    if size:
        raw=json.loads((point / 'custom_c1.json').read_text())
        if raw.get('completed')!=50:raise RuntimeError('Incomplete measurement requests: '+name)
    parse_command=['timeout','120',str(home / 'vllm/.venv/bin/python'),str(root / 'parse-test-capture.py'),str(point / 'requests.pcap')]
    with (point / 'parse.log').open('w') as f:
        parsed=subprocess.run(parse_command,env=env,stdout=f,stderr=subprocess.STDOUT)
    if parsed.returncode:raise RuntimeError('Response capture decoding failed; raw capture preserved')
    subprocess.run(['timeout', '22', str(home / 'vllm/.venv/bin/python'), str(root / 'phase-dmesg.py'), label, name], env=env, check=True)
