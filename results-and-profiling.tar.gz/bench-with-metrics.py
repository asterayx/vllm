#!/home/roccen/vllm/.venv/bin/python
"""Capture vLLM counters around the unchanged benchmark CLI measurement."""
import sys,os,pathlib,json,subprocess,urllib.request,time
args=sys.argv[1:]
def val(flag):return args[args.index(flag)+1] if flag in args else None
out=pathlib.Path(val('--result-dir')) if val('--result-dir') else None
name=val('--result-filename');base=val('--base-url')
def scrape(phase):
 if out is None or name is None:return
 try:
  with urllib.request.urlopen(base+'/metrics',timeout=10) as r:text=r.read().decode()
  (out/(name+'.'+phase+'.metrics')).write_text(text)
  (out/(name+'.'+phase+'.time.json')).write_text(json.dumps({'time_ns':time.time_ns()}))
 except Exception as e:(out/(name+'.'+phase+'.error')).write_text(repr(e))
env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES='',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1')
scrape('before')
cmd=[str(pathlib.Path.home()/'vllm/.venv/bin/vllm'),*args]
main_started=False
if out is None:
 r=subprocess.run(['timeout','-k','15','3300',*cmd],env=env)
else:
 with (out/(name+'.cli.log')).open('w') as f:
  r=subprocess.Popen(['timeout','-k','15','3300',*cmd],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
  for line in r.stdout:
   f.write(line);f.flush();print(line,end='',flush=True)
   if 'Starting main benchmark run...' in line and not main_started:
    scrape('measurement-before');main_started=True
  r.wait()
scrape('after')
if out is not None:(out/(name+'.wrapper.json')).write_text(json.dumps({'command':cmd,'returncode':r.returncode,'measurement_start_captured':main_started},indent=2))
raise SystemExit(r.returncode)

