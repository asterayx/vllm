"""Summarize immutable benchmark outputs; preserve native measurements."""
import collections,csv,json,re,sys
from pathlib import Path
folder=Path(sys.argv[1]); label=sys.argv[2]
summary=[]; all_outputs=[]; candidates=[]
def metrics(path):
 values=collections.defaultdict(float)
 for line in path.read_text().splitlines():
  if not line or line.startswith('#'):continue
  name=line.split('{',1)[0].split()[0]
  try:values[name]+=float(line.rsplit(None,1)[-1])
  except ValueError:pass
 return values
for name in ['realtext3k-1000','realtext10k-1000','realtext32k-1000','realtext10k-4000','multiturn']:
 p=folder/'bench'/name
 if not (p/'requests.outputs.jsonl').exists():continue
 csvs=list(p.glob('*.csv'));data=[]
 for f in csvs:
  for row in csv.DictReader(f.open()):
   if row.get('out_tps'):data.append(row)
 assert len(data)==1, (name,len(data))
 row=data[0];outputs=[json.loads(l) for l in (p/'requests.outputs.jsonl').read_text().splitlines()]
 assert all(' 200 ' in r['response_line'] for r in outputs)
 if name!='multiturn':
  native=json.loads((p/'custom_c1.json').read_text());assert native['completed']==50
  measurement=outputs[-50:];warmup=outputs[:-50]
  assert [r['text'] for r in measurement]==native['generated_texts'], 'Capture differs from native texts'
  before_path=p/'custom_c1.json.measurement-before.metrics';after_path=p/'custom_c1.json.after.metrics'
  exact_tpot=native['median_tpot_ms']; n=native['completed']
 else:
  native=json.loads((p/'mt_c1_stats.json').read_text());native=[r for r in native if r.get('ttft_ms',-1)>0]
  assert len(native)==40 and len(outputs)==40,(len(native),len(outputs))
  measurement=outputs;warmup=[];n=len(native)
  before_path=p/'whole-before.metrics';after_path=p/'whole-after.metrics';exact_tpot=float(row['tpot_p50'])
 before=metrics(before_path);after=metrics(after_path)
 counters={}
 for key in ['vllm:spec_decode_num_drafts_total','vllm:spec_decode_num_accepted_tokens_total','vllm:spec_decode_num_draft_tokens_total','vllm:prefix_cache_hits_total','vllm:prefix_cache_queries_total','vllm:generation_tokens_total']:
  if key in before and key in after:counters[key]=after[key]-before[key]
 drafts=counters.get('vllm:spec_decode_num_drafts_total',0); accepted=counters.get('vllm:spec_decode_num_accepted_tokens_total',0)
 accept=1+accepted/drafts if drafts else 1 if label.startswith('V2') else None
 flags_by_phase=collections.Counter()
 for phase,requests in [('measurement',measurement),('warmup_or_validation',warmup)]:
  for i,r in enumerate(requests,1):
   text=r['text'];flags=[]
   if text.count('\ufffd')>=3:flags.append('replacement_characters')
   if len(re.findall('[\u0400-\u04ff]',text))>=4 and len(re.findall('[\uac00-\ud7af]',text))>=4:flags.append('mixed_cyrillic_hangul_review')
   match=re.search(r'(.{8,160}?)\1{3,}',text,re.S)
   if match:flags.append('repeated_character_block_4plus')
   rec={'load':name,'phase':phase,'request_number':i,**r,'candidate_flags':flags,'repeat_example':match.group(0)[:600] if match else None};all_outputs.append(rec)
   if flags:
    flags_by_phase[phase]+=1;candidates.append({k:v for k,v in rec.items() if k not in ['request_payload','text']})
 summary.append({'load':name,'native_csv':row,'n':n,'capture_matches_native':name!='multiturn','counter_deltas':counters,'counter_window':'measurement only' if name!='multiturn' else 'whole multiround tool','accept_length_including_bonus':accept,'user_tps':1000/exact_tpot,'step_ms':exact_tpot*accept if accept is not None else None,'candidate_counts':dict(flags_by_phase),'sampling_sent_variants':list({json.dumps(r['sampling_fields_sent'],sort_keys=True) for r in measurement})})
(folder/'benchmark-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
(folder/'output-review-candidates.json').write_text(json.dumps(candidates,ensure_ascii=False,indent=2))
with (folder/'all-benchmark-outputs.jsonl').open('w') as f:
 for row in all_outputs:f.write(json.dumps(row,ensure_ascii=False)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
