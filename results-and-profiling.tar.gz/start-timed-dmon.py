import os,json,subprocess,sys
from pathlib import Path
from types import SimpleNamespace
from owned import register
p=Path.home()/'vllm-v034-c1'/sys.argv[1]
assert Path('/proc/self/oom_score_adj').read_text().strip()=='1000'
assert not (p/'exit.json').exists()
register(p,SimpleNamespace(pid=os.getpid()))
with (p/'dmon-timed.log').open('x') as f:
 child=subprocess.Popen(['choom','-n','1000','--','timeout','21600','nvidia-smi','dmon','-i','0,1,4,5','-s','pucm','-d','1','-o','DT'],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
 register(p,child)
 print(json.dumps({'timed_dmon_pid':child.pid}))
