"""External process supervision only; does not modify vLLM or benchmarks."""
import json, os, pathlib, re, signal, socket, subprocess, sys, time, urllib.request, threading

home = pathlib.Path.home()
root = home / 'vllm-v034-c1'
label = sys.argv[1]
out = root / label
out.mkdir(exist_ok=False)
port = 18775
with socket.socket() as sock:
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(('127.0.0.1', port))
env = os.environ.copy()
for key in list(env):
    if key.startswith(('NCCL_', 'QWEN4_', 'ARDELVA_')):
        env.pop(key)
overrides = {
    'CUDA_VISIBLE_DEVICES': '0,1,4,5',
    'CUDA_DEVICE_ORDER': 'PCI_BUS_ID',
    'LIBRARY_PATH': os.environ['LIBRARY_PATH'],
    'VLLM_FLASHINFER_AUTOTUNE_CACHE_DIR': str(root / 'cache/vllm-autotune'),
    'ISSUE55_PROFILE_OUTPUT': str(out / 'profile'),
    'ISSUE55_NSYS_SESSION': 'vllm-v034-c1-r2-' + label.lower(),
    'PYTHONPATH': str(home / 'vllm-integration-v0.34.0'),
    'PATH': str(home / 'vllm-integration-v0.34.0/.venv/bin') + ':' + env['PATH'],
    'QWEN4_EXP_TRITON_GEMM': '1',
    'QWEN4_EXP_TRITON_MOE': '1',
    'QWEN4_EXP_TRITON_MOE_MAX_M': '96',
    'NCCL_MIN_NCHANNELS': '16',
    'NCCL_P2P_LEVEL': 'SYS',
    'NCCL_TUNER_PLUGIN': str(home / 'ardelva/opt2/lltune/libnccl-tuner-ardelva.so'),
    'ARDELVA_LL_MAX_BYTES': '393216',
    'VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC': '1',
    'VLLM_ALLREDUCE_FLASHINFER_PCIE_IPC_MAX_TOKENS': '16',
    'NCCL_DEBUG': 'INFO',
    'NCCL_DEBUG_SUBSYS': 'INIT',
    'VLLM_TUNED_CONFIG_FOLDER': str(home / 'ardelva/opt3/moe_configs'),
    'MAX_JOBS': '1', 'FLASHINFER_NVCC_THREADS': '1',
    'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONUNBUFFERED': '1',
}
overrides.update({k:v for k,v in os.environ.items() if k in ('CUDA_HOME','FLASHINFER_NVCC','LD_LIBRARY_PATH','LIBRARY_PATH','FLASHINFER_WORKSPACE_BASE','FLASHINFER_AUTOTUNE_CACHE_DIR','VLLM_CACHE_ROOT','XDG_CACHE_HOME','CUDA_CACHE_PATH','TRITON_CACHE_DIR','TORCHINDUCTOR_CACHE_DIR','TORCH_EXTENSIONS_DIR','FLASHINFER_LOGGING_LEVEL','CUTE_DSL_CACHE_DIR','CUTE_DSL_DUMP_DIR','TMPDIR')})
env.update(overrides)
(out / 'profile').mkdir()
cmd = [str(home / 'vllm-integration-v0.34.0/.venv/bin/python'), str(root / 'profile-launcher.py'), 'serve',
       str(home / 'models/nvidia/Qwen3.8-Flash-Next-NVFP4'),
       '--tensor-parallel-size', '4', '--max-model-len', '262144', '--max-num-seqs', '64',
       '--gpu-memory-utilization', '0.95', '--reasoning-parser', 'qwen3',
       '--port', str(port), '--numa-bind']
if label.startswith('V1'):
    cmd += ['--speculative-config', json.dumps({'method': 'mtp', 'num_speculative_tokens': 2,
            'moe_backend': 'auto', 'use_local_argmax_reduction': True})]
cmd += ['--moe-backend', 'b12x', '--kv-cache-dtype', 'fp8', '--served-model-name',
        'qwen3.8-flash-next', '--enable-auto-tool-choice', '--tool-call-parser', 'qwen3_coder',
        '--profiler-config', json.dumps({'profiler': 'cuda', 'delay_iterations': 50, 'max_iterations': 64})]
(out / 'command.json').write_text(json.dumps({'cmd': cmd, 'environment_overrides': overrides,
    'startup_timeout_seconds': 5400, 'total_timeout_seconds': 21600,
    'global_guard_GiB': None, 'each_NUMA_guard_GiB': None, 'memory_threshold_disabled_by_user': True, 'oom_score_adj': 1000}, indent=2))

def memory():
    available = int(re.search(r'^MemAvailable:\s+(\d+)', pathlib.Path('/proc/meminfo').read_text(), re.M)[1])
    nodes = {}
    for path in pathlib.Path('/sys/devices/system/node').glob('node*/meminfo'):
        values = {k: int(v) for k, v in re.findall(r'Node \d+ (\w+):\s+(\d+)', path.read_text())}
        nodes[path.parent.name] = values['MemFree'] + max(values['FilePages'] - values['Shmem'], 0) + values.get('SReclaimable', 0)
    return {'time_ns': time.time_ns(), 'available_kib': available, 'node_free_reclaimable_kib': nodes}

def unsafe(sample):
    # User explicitly authorized retry without memory-reserve thresholds.
    # Keep logging memory and stop on actual kernel OOM counter increases.
    return False

def oom_count():
    return int(re.search(r'^oom_kill (\d+)', pathlib.Path('/proc/vmstat').read_text(), re.M)[1])

kernel_since = time.strftime('%Y-%m-%d %H:%M:%S')
initial_oom = oom_count()
(out / 'oom-before.json').write_text(json.dumps({'oom_kill': initial_oom, 'kernel_since': kernel_since}))
monitor_stop = threading.Event()
def kernel_monitor():
    while not monitor_stop.is_set():
        try:
            result = subprocess.run(['timeout', '5', 'sudo', '-n', 'dmesg', '--time-format', 'iso', '--since', kernel_since], capture_output=True, text=True, timeout=7)
            (out / 'kernel-since-start.log').write_text(result.stdout + result.stderr)
            if result.returncode:
                with (out / 'kernel-monitor-warnings.jsonl').open('a') as f:
                    f.write(json.dumps({'time_ns': time.time_ns(), 'returncode': result.returncode, 'stderr': result.stderr}) + '\n')
            if re.search(r'invoked oom-killer|Out of memory:|Killed process .*anon-rss', result.stdout, re.I):
                (out / 'kernel-oom.log').write_text(result.stdout)
                # Supplementary evidence only; vmstat decides OOM shutdown.
                pass
        except Exception as exc:
            with (out / 'kernel-monitor-warnings.jsonl').open('a') as f:
                f.write(json.dumps({'time_ns': time.time_ns(), 'exception': repr(exc)}) + '\n')
        monitor_stop.wait(2)

initial = memory()
(out / 'memory-before.json').write_text(json.dumps(initial, indent=2))
if unsafe(initial):
    (out / 'memory-guard.json').write_text(json.dumps(initial, indent=2))
    sys.exit('Prelaunch memory guard')
stop = False
def shutdown(*args):
    global stop
    stop = True
signal.signal(signal.SIGTERM, shutdown)
signal.signal(signal.SIGINT, shutdown)
start = time.monotonic()
log = (out / 'server.log').open('w')
dlog = (out / 'dmon-timed.log').open('w')
dmon = subprocess.Popen(['timeout', '21600', 'nvidia-smi', 'dmon', '-i', '0,1,4,5', '-s', 'pucm', '-d', '1', '-o', 'DT'], stdout=dlog, stderr=subprocess.STDOUT, start_new_session=True)
p = subprocess.Popen(['choom', '-n', '1000', '--', *cmd], stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
(out / 'pid.json').write_text(json.dumps({'runner_pid': os.getpid(), 'server_pid': p.pid, 'pgid': p.pid, 'dmon_pgid': dmon.pid}))
ready = False
reason = 'server_exited'
thread = threading.Thread(target=kernel_monitor, daemon=True)
thread.start()
seen_oom_pids = set()
owned_start_ticks = {}
startup_stage = 'startup'
def stage():
    global startup_stage
    if (out / 'phase.txt').exists():
        return (out / 'phase.txt').read_text().strip()
    if ready:
        return 'ready_idle'
    with (out / 'server.log').open('rb') as f:
        f.seek(0,2); f.seek(max(0,f.tell()-65536)); tail=f.read().decode(errors='replace')
    if 'Graph capturing finished' in tail or 'Warming up CuTeDSL' in tail:
        startup_stage = 'startup_kernel_warmup'
    elif 'Capturing CUDA graphs' in tail and startup_stage == 'startup':
        startup_stage = 'graph_capture'
    return startup_stage

def snapshot_oom():
    census = {}
    for proc in pathlib.Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().rsplit(') ', 1)[1].split()
            census[int(proc.name)] = (int(fields[1]), int(fields[2]), int(fields[19]))
        except (OSError, ValueError):
            pass
    owned = {pid for pid, info in census.items() if info[1] == p.pid}
    owned.update(pid for pid, tick in owned_start_ticks.items()
                 if pid in census and census[pid][2] == tick)
    registry = out / 'owned-helpers.jsonl'
    if registry.exists():
        for line in registry.read_text().splitlines():
            try:
                row = json.loads(line)
                pid = row['pid']
                if pid in census and census[pid][2] == row['start_ticks']:
                    owned.add(pid)
            except (ValueError, KeyError):
                pass
    for _ in range(12):
        children = {pid for pid, info in census.items() if info[0] in owned}
        if children <= owned:
            break
        owned.update(children)
    owned_start_ticks.update({pid: census[pid][2] for pid in owned})
    for proc in pathlib.Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) in seen_oom_pids:
            continue
        try:
            pid=int(proc.name)
            if pid not in owned:
                continue
            score=int((proc/'oom_score_adj').read_text())
            comm=(proc/'comm').read_text().strip()
            row={'time_ns':time.time_ns(),'pid':pid,'pgid':os.getpgid(pid),'start_ticks':census[pid][2],'comm':comm,'oom_score_adj':score}
            with (out/'oom-processes.jsonl').open('a') as f:
                f.write(json.dumps(row)+'\n')
            # choom may briefly exist before it has applied its own adjustment.
            if score==1000:
                seen_oom_pids.add(pid)
            elif comm!='choom':
                (out/'oom-inheritance-failure.json').write_text(json.dumps(row))
                return False
        except (OSError,ValueError):
            pass
    return True
try:
    while p.poll() is None:
        sample = memory()
        sample['stage'] = stage()
        sample['oom_kill'] = oom_count()
        with (out / 'memory.jsonl').open('a') as f:
            f.write(json.dumps(sample) + '\n')
        if sample['oom_kill'] > initial_oom:
            (out / 'oom-stop.json').write_text(json.dumps(sample, indent=2))
            reason = 'vmstat_oom_kill_increased'; break
        if not snapshot_oom():
            reason = 'oom_inheritance_failure'; break
        if unsafe(sample):
            (out / 'memory-guard.json').write_text(json.dumps(sample, indent=2))
            reason = 'memory_guard'; break
        if stop:
            reason = 'requested_stop'; break
        elapsed = time.monotonic() - start
        if elapsed > 21600 or (not ready and elapsed > 5400):
            reason = 'runtime_timeout' if ready else 'startup_timeout'; break
        if not ready:
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/health', timeout=0.3) as response:
                    ready = response.status == 200
                if ready:
                    (out / 'ready.json').write_text(json.dumps({'seconds': elapsed, 'memory': sample, 'time_ns': time.time_ns()}, indent=2))
                    with (out / 'gpu-ready.csv').open('w') as f:
                        subprocess.run(['timeout', '10', 'nvidia-smi', '--query-gpu=index,uuid,memory.used,utilization.gpu', '--format=csv'], stdout=f, timeout=12)
                    print('READY', elapsed, flush=True)
            except (OSError, TimeoutError):
                pass
        time.sleep(0.5)
finally:
    monitor_stop.set()
    def stop_owned(sig):
        for pid, tick in owned_start_ticks.items():
            try:
                fields = pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(') ', 1)[1].split()
                if int(fields[19]) == tick:
                    os.kill(pid, sig)
            except (OSError, ValueError):
                pass
    stop_owned(signal.SIGKILL if reason == 'vmstat_oom_kill_increased' else signal.SIGTERM)
    for proc in [p, dmon]:
        try:
            os.killpg(proc.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    try:
        p.wait(timeout=25)
    except subprocess.TimeoutExpired:
        pass
    for proc in [p, dmon]:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        proc.wait(timeout=10)
    stop_owned(signal.SIGKILL)
    log.close(); dlog.close()
    (out / 'exit.json').write_text(json.dumps({'returncode': p.returncode, 'ready': ready, 'reason': reason, 'seconds': time.monotonic() - start, 'memory': memory(), 'oom_kill_before': initial_oom, 'oom_kill_after': oom_count()}, indent=2))
    print('EXIT', reason, p.returncode, flush=True)
