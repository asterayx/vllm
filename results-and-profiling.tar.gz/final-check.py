import csv,io,json,pathlib,re,subprocess,time
r=pathlib.Path.home()/'vllm-v034-c1';home=pathlib.Path.home()
def cmd(args):return subprocess.check_output(args,text=True,timeout=45).strip()
checks={'time_ns':time.time_ns()}
for label,folder in [('integration','vllm-integration-v0.34.0'),('serving','vllm')]:
 text=cmd([str(home/'.local/bin/uv'),'pip','freeze','--python',str(home/folder/'.venv/bin/python')])+'\n'
 (r/f'packages-{label}-after.txt').write_text(text)
 checks[label+'_packages_unchanged']=text==(r/f'packages-{label}-before.txt').read_text()
 checks[label+'_head']=cmd(['git','-C',str(home/folder),'rev-parse','HEAD'])
 checks[label+'_status']=cmd(['git','-C',str(home/folder),'status','--porcelain'])
checks['integration_source_unchanged']=checks['integration_head']==(r/'source-before.txt').read_text().strip() and not checks['integration_status']
res=subprocess.run(['sha256sum','-c',str(r/'inputs-before.sha256')],capture_output=True,text=True,timeout=60)
(r/'inputs-after-check.txt').write_text(res.stdout+res.stderr);checks['benchmark_and_inputs_unchanged']=res.returncode==0
raw=cmd(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv'])+'\n';(r/'gpu-processes-after.csv').write_text(raw)
def processes(s):return {(x['pid'].strip(),x[' gpu_uuid'].strip()) for x in csv.DictReader(io.StringIO(s))}
checks['existing_gpu_processes_unchanged']=processes(raw)==processes((r/'gpu-processes-before.csv').read_text())
checks['gpu_processes_after']=sorted(processes(raw))
checks['oom_kill_after']=int(re.search(r'^oom_kill (\d+)',pathlib.Path('/proc/vmstat').read_text(),re.M)[1])
checks['oom_kill_before']=json.loads((r/'V2-attempt1/oom-before.json').read_text())['oom_kill']
checks['no_new_oom']=checks['oom_kill_after']==checks['oom_kill_before']
checks['sequence_complete']=(r/'sequence-complete.json').exists()
for label in ['V2','V1']:
 checks[label+'_exit']=json.loads((r/label/'exit.json').read_text())
 checks[label+'_nsys_report_exists']=(r/label/'profile/trace.nsys-rep').exists()
(r/'verification.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(checks,indent=2))
assert all(checks[k] for k in ['integration_packages_unchanged','serving_packages_unchanged','integration_source_unchanged','benchmark_and_inputs_unchanged','existing_gpu_processes_unchanged','no_new_oom','sequence_complete'])
