"""Collect supported Nsight evidence; leave boundary interpretation reviewable."""
import json, os, pathlib, subprocess, sys
root=pathlib.Path.home()/'vllm-v034-c1'
label=sys.argv[1]
out=root/label/'analysis';out.mkdir(exist_ok=True)
analysis=pathlib.Path.home()/'strata-issue55/round5/offline-7063939719'
env=os.environ.copy();env.update(PYTHONPATH=(analysis/'site-packages-path.txt').read_text().strip(),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',NSYSPYTHONEXE=str(analysis/'venv/bin/python'))
py='/opt/nvidia/nsight-systems/2026.5.2/target-linux-x64/python/bin/python'
cli='/opt/nvidia/nsight-systems/2026.5.2/skills/nsight-systems/scripts/nsys_skill_cli.py'
nsys='/opt/nvidia/nsight-systems/2026.5.2/target-linux-x64/nsys'
report=root/label/'profile/trace.nsys-rep'
def run(name,command,args,report_arg=True):
 existing=out/(name+'.json')
 if existing.exists():
  try:
   saved=json.loads(existing.read_text());cached=saved.get('data',saved)
   if saved.get('ok',True) and cached.get('ok',True):return cached
  except (ValueError,TypeError):pass
 cmd=[py,cli,command]+(['--report',str(report),'--nsys-path',nsys] if report_arg else [])+args
 p=subprocess.run(cmd,env=env,text=True,capture_output=True,timeout=600)
 (out/(name+'.json')).write_text(p.stdout)
 (out/(name+'.stderr')).write_text(p.stderr)
 x=json.loads(p.stdout);d=x.get('data',x)
 if p.returncode or not x.get('ok',True) or not d.get('ok',True):raise RuntimeError((name,p.returncode,d.get('error')))
 print(name,'complete',flush=True);return d

def q(name,sql):return run(name,'report-query',['--sql',sql,'--max-rows','1000','--max-chars','240000'])
run('context','report-context',[])
for f in ['activity_summary','kernel_summary','cuda_api_summary','nvtx_presence','gpu_devices']:
 run(f,'report-fact',['--type',f])
for table in ['CUPTI_ACTIVITY_KIND_KERNEL','CUPTI_ACTIVITY_KIND_RUNTIME','NVTX_EVENTS','StringIds']:
 run('schema-'+table,'report-describe',['--table',table])
projection=run('projection','run-recipe',['--recipe','nvtx_gpu_proj_trace','--timeout','300','--','--mode','none'])
handle=projection['output_label']
run('projection-schema','recipe-output-schema',['--output-label',handle],False)
# These column names belong to the official GPU projection trace recipe.
projected=run('projected-ranges','recipe-output-query',['--output-label',handle,'--sql','SELECT "Text", "Start", "End" FROM trace WHERE "Text" LIKE \'execute_context_0(0)_generation_1%\' ORDER BY "Start"','--max-rows','1000','--max-chars','120000'],False)
rows=projected['rows']
if len(rows)!=64:raise RuntimeError(f'Expected 64 projected decode steps, found {len(rows)}')
start=min(r['Start'] for r in rows)
cpu_ranges=q('nvtx-ranges','SELECT coalesce(n.text,s.value) AS name,n.start,n."end" FROM NVTX_EVENTS n LEFT JOIN StringIds s ON n.textId=s.id WHERE coalesce(n.text,s.value) LIKE \'execute_context_0(0)_generation_1%\' ORDER BY n.start LIMIT 1000')['rows']
q('api-startstop',"SELECT s.value AS name,r.start,r.\"end\" FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON r.nameId=s.id WHERE s.value LIKE '%Profiler%' ORDER BY r.start LIMIT 200")
summary=q('window-summary',f'SELECT count(*) AS launches,sum("end"-start) AS kernel_ns,min(start) AS first_start,max("end") AS last_end FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE start>={start}')['rows'][0]
q('window-kernels',f'SELECT s.value AS name,count(*) AS n,sum(k."end"-k.start) AS ns,min(k."end"-k.start) AS min_ns,max(k."end"-k.start) AS max_ns FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON k.demangledName=s.id WHERE k.start>={start} GROUP BY s.value ORDER BY ns DESC')
q('launch-shapes',f'SELECT s.value AS name,k.gridX,k.gridY,k.gridZ,k.blockX,k.blockY,k.blockZ,count(*) AS n,sum(k."end"-k.start) AS ns FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON k.demangledName=s.id WHERE k.start>={start} GROUP BY ALL ORDER BY ns DESC')
q('graphs',f'SELECT graphId,count(*) AS n,count(distinct correlationId) AS calls,min(start) AS first_start,max("end") AS last_end,sum("end"-start) AS ns FROM CUPTI_ACTIVITY_KIND_KERNEL WHERE start>={start} GROUP BY graphId ORDER BY ns DESC')
q('graph-kernels',f'SELECT k.graphId,s.value AS name,count(*) AS n,sum(k."end"-k.start) AS ns FROM CUPTI_ACTIVITY_KIND_KERNEL k JOIN StringIds s ON k.demangledName=s.id WHERE k.start>={start} GROUP BY k.graphId,s.value ORDER BY k.graphId,ns DESC LIMIT 1000')
q('window-api',f'SELECT s.value AS name,count(*) AS n,sum(r."end"-r.start) AS ns FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON r.nameId=s.id WHERE r.start>={start} AND r.start<{summary["last_end"]} GROUP BY s.value ORDER BY ns DESC LIMIT 20')
if len(cpu_ranges)==64:
 cpu_start,cpu_end=cpu_ranges[0]['start'],cpu_ranges[-1]['start']
 q('window-api-clipped',f'SELECT s.value AS name,count(*) AS n,sum(least(r."end",{cpu_end})-greatest(r.start,{cpu_start})) AS ns FROM CUPTI_ACTIVITY_KIND_RUNTIME r JOIN StringIds s ON r.nameId=s.id WHERE r.start<{cpu_end} AND r."end">{cpu_start} GROUP BY s.value ORDER BY ns DESC LIMIT 20')
(out/'boundary-review.json').write_text(json.dumps({'steps':64,'start_ns':start,'last_kernel_end_ns':summary['last_end'],'review_required':'Check graph replay counts and final step completeness before reporting per-step values; CUDA API window is GPU timeline window, not entire client request.'},indent=2))
