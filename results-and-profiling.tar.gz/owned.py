"""Register this task's helper process for guard cleanup, with PID reuse checks."""
import json
from pathlib import Path
import time


def register(out, process):
    try:
        fields = Path(f'/proc/{process.pid}/stat').read_text().rsplit(') ', 1)[1].split()
    except FileNotFoundError:
        return
    row = {'pid': process.pid, 'start_ticks': int(fields[19]), 'time_ns': time.time_ns()}
    with (Path(out) / 'owned-helpers.jsonl').open('a') as f:
        f.write(json.dumps(row) + '\n')
