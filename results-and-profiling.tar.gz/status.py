from pathlib import Path
import json,re,time
r=Path.home()/'vllm-v034-c1'
for label in ['V2','V1']:
 if label=='V2' and (r/'V1').exists():continue
 p=r/label
 if not p.exists():continue
 row={'label':label}
 for name in ['ready.json','exit.json']:
  if (p/name).exists():
   d=json.loads((p/name).read_text());row[name]={k:d[k] for k in ['seconds','reason','returncode'] if k in d}
 if (p/'phase.txt').exists():row['phase']=(p/'phase.txt').read_text()
 if (p/'memory.jsonl').exists():
  with (p/'memory.jsonl').open('rb') as f:
   f.seek(0,2);f.seek(max(0,f.tell()-2048));s=f.read().decode().splitlines()[-1]
  m=json.loads(s);row['memory_GiB']=round(m['available_kib']/1024**2,2);row['oom_kill']=m['oom_kill']
 if (p/'bench/status.json').exists():row['finished_loads']=[x['load'] for x in json.loads((p/'bench/status.json').read_text())]
 if (p/'bench/active.json').exists():
  a=json.loads((p/'bench/active.json').read_text());point=p/'bench'/a['load'];row['active_load']=a['load']
  c=point/'custom_c1.json.cli.log'
  if not c.exists():c=point/'bench.log'
  if c.exists():
   with c.open('rb') as f:f.seek(0,2);f.seek(max(0,f.tell()-500));row['bench_tail']=f.read().decode(errors='replace')[-200:].replace('\r',' ')
 with (p/'server.log').open('rb') as f:
  f.seek(0,2);f.seek(max(0,f.tell()-1200));row['server_tail']=f.read().decode(errors='replace').splitlines()[-1][-260:]
 print(json.dumps(row,ensure_ascii=False),flush=True)
for name in ['sequence-error.txt','sequence-complete.json']:
 if (r/name).exists():print(name,(r/name).read_text(),flush=True)
