"""Decode only this test endpoint's plaintext HTTP capture; never affects requests."""
import collections, json, pathlib, socket, struct, sys

path = pathlib.Path(sys.argv[1])
flows = {}
active = {}
problems = []
with path.open('rb') as f:
    header = f.read(24)
    formats = {b'\xd4\xc3\xb2\xa1': ('<',1000), b'\xa1\xb2\xc3\xd4': ('>',1000), b'\x4d\x3c\xb2\xa1': ('<',1), b'\xa1\xb2\x3c\x4d': ('>',1)}
    endian, scale = formats[header[:4]]
    linktype = struct.unpack(endian+'I',header[20:24])[0]
    assert linktype == 1, ('Expected Ethernet loopback capture',linktype)
    while packet_header := f.read(16):
        assert len(packet_header)==16
        sec, subsec, length, original = struct.unpack(endian+'IIII',packet_header)
        packet = f.read(length)
        assert len(packet)==length and length==original, 'Truncated capture'
        if len(packet)<34 or packet[12:14]!=b'\x08\x00': continue
        ip=packet[14:]
        ihl=(ip[0]&15)*4
        if ip[9]!=6: continue
        total=struct.unpack('!H',ip[2:4])[0]
        tcp=ip[ihl:total or len(ip)]
        if len(tcp)<20: continue
        sport,dport,seq=struct.unpack('!HHI',tcp[:8])
        if 18775 not in (sport,dport): continue
        direction='response' if sport==18775 else 'request'
        client_port=dport if direction=='response' else sport
        client_ip=socket.inet_ntoa(ip[16:20] if direction=='response' else ip[12:16])
        client=(client_ip,client_port)
        if direction=='request' and tcp[13]&2 and not tcp[13]&16:
            key=(client,seq)
            active[client]=key
        key=active.get(client,(client,None))
        flow=flows.setdefault(key,{'request':{},'response':{}})
        payload=tcp[(tcp[12]>>4)*4:]
        if not payload:continue
        old=flow[direction].get(seq)
        if old and old[0]!=payload:
            # Segmentation can differ on retransmit; choose the larger prefix.
            assert old[0].startswith(payload) or payload.startswith(old[0]), 'Conflicting retransmit'
        if not old or len(payload)>len(old[0]):flow[direction][seq]=(payload,sec*10**9+subsec*scale)

def reassemble(segments):
    result=bytearray(); spans=[]
    if not segments:return b'',spans
    base=min(segments);cursor=base
    for seq,(data,stamp) in sorted(segments.items()):
        if seq>cursor:raise ValueError('TCP sequence gap')
        overlap=min(len(data),cursor-seq)
        if overlap:
            assert result[seq-base:seq-base+overlap]==data[:overlap], 'TCP overlap differs'
        if len(data)>overlap:
            spans.append((len(result),stamp));result.extend(data[overlap:]);cursor=seq+len(data)
    return bytes(result),spans

def messages(data,spans):
    result=[];pos=0
    while pos<len(data):
        start=pos;end=data.find(b'\r\n\r\n',pos)
        if end<0:raise ValueError('Incomplete HTTP header')
        lines=data[pos:end].split(b'\r\n');first=lines[0].decode('ascii')
        headers={k.lower():v.strip() for k,v in (line.split(b':',1) for line in lines[1:])}
        pos=end+4
        if b'chunked' in headers.get(b'transfer-encoding',b''):
            body=bytearray()
            while True:
                end=data.find(b'\r\n',pos)
                if end<0:raise ValueError('Incomplete chunk header')
                size=int(data[pos:end].split(b';',1)[0],16);pos=end+2
                if size==0:
                    if data[pos:pos+2]==b'\r\n':pos+=2
                    else:
                        end=data.find(b'\r\n\r\n',pos)
                        if end<0:raise ValueError('Incomplete HTTP trailers')
                        pos=end+4
                    break
                if len(data)<pos+size+2:raise ValueError('Incomplete chunk')
                body.extend(data[pos:pos+size]);pos+=size
                assert data[pos:pos+2]==b'\r\n';pos+=2
            body=bytes(body)
        elif b'content-length' in headers:
            size=int(headers[b'content-length']);body=data[pos:pos+size]
            if len(body)!=size:raise ValueError('Incomplete content-length body')
            pos+=size
        else:
            if first.startswith(('GET ','HEAD ')):body=b''
            else:body=data[pos:];pos=len(data)
        stamp=next((t for offset,t in reversed(spans) if offset<=start),None)
        result.append({'first':first,'body':body,'time_ns':stamp})
    return result

ignored_non_inference=[]
outputs=[]
for key,flow in flows.items():
    try:
        requests=messages(*reassemble(flow['request']))
        if requests and all(r['first'].split(' ', 2)[0] == 'GET' and r['first'].split(' ', 2)[1] in ['/metrics', '/health', '/v1/models'] for r in requests):
            ignored_non_inference.append({'flow': repr(key), 'requests': [r['first'] for r in requests]})
            continue
        responses=messages(*reassemble(flow['response']))
        if len(requests)!=len(responses):raise ValueError(f'HTTP count mismatch {len(requests)} != {len(responses)}')
        for req,res in zip(requests,responses):
            if not req['first'].startswith('POST ') or not any(p in req['first'] for p in ['/v1/completions','/v1/chat/completions']):continue
            payload=json.loads(req['body']);text=[];reasoning=[];events=0
            if payload.get('stream'):
                for line in res['body'].splitlines():
                    if not line.startswith(b'data:'):continue
                    content=line[5:].strip()
                    if content==b'[DONE]':continue
                    event=json.loads(content);events+=1
                    for choice in event.get('choices',[]):
                        if 'text' in choice:text.append(choice.get('text') or '')
                        delta=choice.get('delta',{})
                        if delta.get('content'):text.append(delta['content'])
                        thought=delta.get('reasoning') or delta.get('reasoning_content')
                        if thought:reasoning.append(thought);text.append(thought)
            else:
                event=json.loads(res['body']);events=1
                for choice in event.get('choices',[]):
                    message=choice.get('message',{})
                    text.append(choice.get('text') or message.get('content') or '')
                    reasoning.append(message.get('reasoning') or message.get('reasoning_content') or '')
            outputs.append({'time_ns':req['time_ns'],'request_line':req['first'],'response_line':res['first'],
                'request_payload':payload,
                'sampling_fields_sent':{k:payload[k] for k in ['temperature','top_p','top_k','ignore_eos','max_tokens','stream'] if k in payload},
                'text':''.join(text),'reasoning':''.join(reasoning),'stream_events':events})
    except Exception as exc:problems.append({'flow':repr(key),'error':repr(exc)})
outputs.sort(key=lambda x:x['time_ns'] or 0)
with path.with_suffix('.outputs.jsonl').open('w') as f:
    for row in outputs:f.write(json.dumps(row,ensure_ascii=False)+'\n')
summary={'flows':len(flows),'outputs':len(outputs),'problems':problems,'ignored_non_inference_flows':ignored_non_inference}
path.with_suffix('.parse-summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
if problems:sys.exit(1)
