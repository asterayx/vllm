import datetime,json,pathlib,statistics,sys
p=pathlib.Path(sys.argv[1]);zone=datetime.timezone(datetime.timedelta(hours=8));samples=[]
for l in (p/'dmon-timed.log').read_text().splitlines():
 if l.startswith('#'):continue
 a=l.split()
 if len(a)<17:continue
 stamp=datetime.datetime.strptime(a[0]+' '+a[1],'%Y%m%d %H:%M:%S').replace(tzinfo=zone).timestamp()*1e9
 samples.append({'time_ns':stamp,'gpu':int(a[2]),'sm':int(a[6]),'memory_MiB':int(a[14])})
result={}
for point in (p/'bench').iterdir():
 if not point.is_dir():continue
 markers=list(point.glob('*measurement-before.time.json'));ends=list(point.glob('*.after.time.json'))
 if markers and ends:
  start=json.loads(markers[0].read_text())['time_ns'];end=json.loads(ends[0].read_text())['time_ns']
 elif point.name=='multiturn' and (p/'bench/status.json').exists():
  row=next((x for x in json.loads((p/'bench/status.json').read_text()) if x['load']=='multiturn'),None)
  if row is None:continue
  start,end=row['start_ns'],row['end_ns']
 else:continue
 out={}
 for gpu in [0,1,4,5]:
  vals=[s['sm'] for s in samples if s['gpu']==gpu and start<=s['time_ns']<=end]
  if vals:out[gpu]={'n':len(vals),'min':min(vals),'median':statistics.median(vals),'max':max(vals)}
 result[point.name]={'window_ns':[start,end],'per_gpu':out}
(p/'dmon-summary.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
