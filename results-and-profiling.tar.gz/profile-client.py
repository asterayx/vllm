"""Profile one existing worker using the exact captured 10K->4000 request.

No model restart, benchmark edit, or sampling change. Py-spy and Nsight use
separate request intervals; throughput here is never a formal benchmark point.
"""
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.request
from types import SimpleNamespace

from owned import register

root = Path.home() / 'vllm-v034-c1'
label, mode = sys.argv[1:3]
assert mode in ['pyspy', 'nsys']
out = root / label
profile = out / 'profile'
register(out, SimpleNamespace(pid=os.getpid()))
assert Path('/proc/self/oom_score_adj').read_text().strip() == '1000'
assert not (out / 'exit.json').exists()
source = out / 'bench/realtext10k-4000/requests.outputs.jsonl'
sample = next(json.loads(line) for line in source.open() if json.loads(line)['request_payload'].get('max_tokens') == 4000)
payload = sample['request_payload']
assert payload.get('stream') and payload.get('ignore_eos')
(profile / (mode + '-request.json')).write_text(json.dumps(payload, ensure_ascii=False, indent=2))
worker = int(re.search(r'\(Worker_TP0 pid=(\d+)\)', (out / 'server.log').read_text())[1])
assert Path(f'/proc/{worker}/oom_score_adj').read_text().strip() == '1000'
worker_stat = Path(f'/proc/{worker}/stat').read_text().rsplit(') ', 1)[1].split()
(profile / (mode + '-worker.json')).write_text(json.dumps({'pid': worker, 'start_ticks': int(worker_stat[19])}))
(out / 'phase.txt').write_text('profile_' + mode)
nsys = '/opt/nvidia/nsight-systems/2026.5.2/target-linux-x64/nsys'
session = json.loads((out / 'command.json').read_text())['environment_overrides']['ISSUE55_NSYS_SESSION']
commands = []
def bounded(command, name, seconds=20):
    result = subprocess.run(['timeout', '--kill-after=3', str(seconds), *command], capture_output=True, text=True, timeout=seconds+5)
    record = {'command': command, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'time_ns': time.time_ns()}
    (profile / (name + '.json')).write_text(json.dumps(record, indent=2))
    commands.append(record)
    return result

if mode == 'nsys':
    status = bounded([nsys, 'status', '--session=' + session], 'nsys-before')
    assert status.returncode == 0 and 'not found' not in status.stdout.lower(), status.stdout + status.stderr
    # start-later defers collection; start arms the requested CUDA API range.
    result = bounded([nsys, 'start', '--session=' + session, '--capture-range=cudaProfilerApi', '--capture-range-end=stop', '--sample=none', '--cpuctxsw=none', '--output=' + str(profile / 'trace')], 'nsys-start')
    if result.returncode:
        raise RuntimeError('Nsight start failed; keep the same model instance and inspect saved CLI output')

spy = None
trigger_thread = None
trigger_errors = []
triggered = False
rows = []

def arm_cuda_range():
    try:
        before = time.time_ns()
        req = urllib.request.Request('http://127.0.0.1:18775/start_profile', data=b'', method='POST')
        with urllib.request.urlopen(req, timeout=30) as response:
            body = response.read().decode()
            status = response.status
        (profile / 'cuda-profiler-trigger.json').write_text(json.dumps({'start_ns': before, 'end_ns': time.time_ns(), 'status': status, 'response': body, 'delay_worker_steps': 50, 'maximum_profiled_steps': 64}, indent=2))
    except Exception as exc:
        trigger_errors.append(repr(exc))

try:
    # Three serial 4000-token requests keep even the faster MTP case active
    # through a 30s Python sample. Request boundaries are retained explicitly.
    for index in range(3 if mode == 'pyspy' else 1):
        assert not (out / 'exit.json').exists(), 'Guard stopped the model'
        req = urllib.request.Request('http://127.0.0.1:18775/v1/completions', data=json.dumps(payload).encode(), headers={'Content-Type': 'application/json'})
        begin = time.time_ns()
        first = None
        last = None
        text = []
        usage = None
        chunks = 0
        with urllib.request.urlopen(req, timeout=300) as response, (profile / (mode + f'-request-{index}.events.jsonl')).open('w') as events:
            for line in response:
                if not line.startswith(b'data:'):
                    continue
                value = line[5:].strip()
                if value == b'[DONE]':
                    break
                event = json.loads(value)
                now = time.time_ns()
                events.write(json.dumps({'time_ns': now, 'event': event}, ensure_ascii=False) + '\n')
                if event.get('usage'):
                    usage = event['usage']
                for choice in event.get('choices', []):
                    content = choice.get('text') or ''
                    if content:
                        first = first or now
                        last = now
                        chunks += 1
                        text.append(content)
                        if not triggered:
                            triggered = True
                            if mode == 'nsys':
                                trigger_thread = threading.Thread(target=arm_cuda_range)
                                trigger_thread.start()
                            else:
                                log = (profile / 'pyspy-cli.log').open('w')
                                # Yama ptrace_scope=1: read-only attach to the owned worker requires sudo.
                                command = ['sudo', '-n', 'choom', '-n', '1000', '--', 'timeout', '--kill-after=5', '40', str(Path.home() / 'vllm/.venv/bin/py-spy'), 'record', '--pid', str(worker), '--duration', '30', '--rate', '100', '--format', 'speedscope', '--output', str(profile / 'worker.speedscope.json')]
                                spy = subprocess.Popen(['choom', '-n', '1000', '--', 'timeout', '--kill-after=5', '40', *command], stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                                register(out, spy)
                                (profile / 'pyspy-command.json').write_text(json.dumps({'command': command, 'pid': spy.pid, 'start_ns': now}, indent=2))
        row = {'index': index, 'start_ns': begin, 'end_ns': time.time_ns(), 'first_text_ns': first, 'last_text_ns': last, 'chunks': chunks, 'usage': usage, 'text': ''.join(text)}
        rows.append(row)
        (profile / (mode + '-requests.json')).write_text(json.dumps(rows, ensure_ascii=False, indent=2))
        if mode == 'pyspy' and spy is not None and spy.poll() is not None:
            break
    if trigger_thread:
        trigger_thread.join(timeout=35)
        assert not trigger_thread.is_alive()
        assert not trigger_errors, trigger_errors
    if spy is not None:
        spy.wait(timeout=45)
        assert spy.returncode == 0, 'py-spy failed; see pyspy-cli.log'
    if mode == 'nsys':
        bounded([nsys, 'status', '--session=' + session], 'nsys-after')
    (profile / (mode + '-status.json')).write_text(json.dumps({'completed': True, 'requests': len(rows), 'commands': commands, 'trigger_errors': trigger_errors}, indent=2))
finally:
    if spy is not None and spy.poll() is None:
        try:
            os.killpg(spy.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
