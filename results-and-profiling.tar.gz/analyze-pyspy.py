"""Summarize sampled stacks, not wall-time CPU utilization."""
import collections,json,pathlib,sys
p=pathlib.Path(sys.argv[1]);d=json.loads(p.read_text());frames=d['shared']['frames'];rows=[]
for profile in d['profiles']:
 if profile.get('type')!='sampled':continue
 samples=profile['samples'];weights=profile.get('weights') or [1]*len(samples)
 assert len(samples)==len(weights)
 leaf=collections.Counter();inclusive=collections.Counter();total=0
 for sample,weight in zip(samples,weights):
  if not sample:continue
  total+=weight;leaf[sample[-1]]+=weight
  for index in set(sample):inclusive[index]+=weight
 def top(counter):
  return [{'frame':frames[k],'weight':w,'sampled_weight_percent':100*w/total} for k,w in counter.most_common(12)] if total else []
 rows.append({'profile':profile.get('name'),'unit':profile.get('unit'),'samples':len(samples),'sampled_weight':total,'top_leaf':top(leaf),'top_inclusive':top(inclusive)})
out=p.with_name('pyspy-summary.json');out.write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(json.dumps(rows,ensure_ascii=False,indent=2))
