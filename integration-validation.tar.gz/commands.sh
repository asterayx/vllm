#!/usr/bin/env bash
set -euo pipefail
cd /home/roccen/vllm-integration-v0.34.0
export CUDA_VISIBLE_DEVICES=0
export CUDA_HOME=/usr/local/cuda-13.5
export FLASHINFER_NVCC="$CUDA_HOME/bin/nvcc"
export PATH="$PWD/.venv/bin:$HOME/.local/bin:$PATH"
.venv/bin/python -m pytest -q tests/models/test_deepseek_v41_rtxpro5000_fixes.py tests/v1/worker/test_draft_tokens_handler.py tests/utils_/test_dpsk_nvtx.py tests/model_executor/test_flashinfer_autotune_warmup.py tests/quantization/test_trtllm_nvfp4_hidden_dim_padding.py tests/kernels/test_engram.py -k 'not head_shards_reconstruct and not multi_gpu and not engram_lookup and not engram_post' --tb=short
.venv/bin/python -m pytest -q tests/v1/core/test_scheduler.py tests/v1/core/test_async_scheduler.py -k 'draft or persist or grammar' --tb=short
.venv/bin/python -m pytest -q tests/v1/structured_output/test_structured_output_manager.py tests/parser/engine/test_glm47_moe.py tests/entrypoints/openai/test_tool_calls_serialization.py tests/distributed/test_flashinfer_pcie_ipc_all_reduce.py --tb=short
QWEN4_EXP_TRITON_MOE=1 .venv/bin/python -m pytest -q 'tests/kernels/moe/test_b12x.py::test_b12x_nvfp4_moe_small_batch_unaligned_intermediate[1-160]' 'tests/kernels/moe/test_b12x.py::test_b12x_nvfp4_moe_small_batch_unaligned_intermediate[8-160]' 'tests/kernels/moe/test_b12x.py::test_b12x_nvfp4_moe_small_batch_unaligned_intermediate[32-160]' 'tests/kernels/moe/test_b12x.py::test_b12x_nvfp4_moe_small_batch_unaligned_intermediate[96-160]' --tb=short
xargs .venv/bin/pre-commit run --files < /home/roccen/vllm-v034-validation/vllm-v034-validation-files.txt
