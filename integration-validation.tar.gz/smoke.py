def main():
    import json, sys
    from pathlib import Path
    import vllm
    from vllm import LLM, SamplingParams
    source = Path(vllm.__file__).resolve()
    assert str(source).startswith(sys.argv[1]), source
    prompts = [
        "The capital of France is",
        "Question: What is 2 + 2? Answer:",
        "Write a Python function that returns the square of a number:\n",
    ]
    llm = LLM(
        model="Qwen/Qwen3-0.6B", seed=0, enforce_eager=True,
        max_model_len=256, max_num_seqs=4, max_num_batched_tokens=256,
        gpu_memory_utilization=0.1, enable_prefix_caching=False,
    )
    outputs = llm.generate(prompts, SamplingParams(temperature=0, max_tokens=24))
    result = {
        "source":str(source), "model":"Qwen/Qwen3-0.6B",
        "outputs":[{"prompt":p, "tokens":o.outputs[0].token_ids, "text":o.outputs[0].text}
                   for p,o in zip(prompts, outputs, strict=True)],
    }
    Path(sys.argv[2]).write_text(json.dumps(result, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
